﻿                               ONLINE PLACEMENT AUTOMATION SYSTEM
							   
							   
					  
This "readme" file contains important information about Online Placement Automation System.
To know the in depth knowledge of this website,read this file in its entirety.


				TABLE OF CONTENTS
				 ----------------

1. Hardware and software Requirements
2. Constraints
3. Features
4. Installation


1.PERFORMANCE REQUIREMENTS

	- Hardware Interface
			1. Server side requirement
				•	Processor: Pentium p4 (1-2 GHZ) or onwards.
				•	RAM: 1 GB or more.
				•	HDD: 20 GB (free space excluding data size).
       			2. Client side requirements
				•	Processor: Pentium p2 (1 GHZ) or onwards.
				•	RAM: 512 MB or more
				•	HDD: 8 GB or more.
			3. Developer side requirements
				•	Processor: Pentium p4 (1-2 GHZ) or onwards.
				•	RAM: 2 GB or more.
				•	HDD: 40 GB or more

	- Software Interface
			1. Server side requirements
				•	Operating system: Microsoft Windows Server 2000
				•	Web server: Apache Tomcat7.0
   			2. Client side requirements
				•	Operating system: Any operating system.
				•	Browser: Mozilla Firefox
  			3. Developer side requirement
				•	Operating system: Windows XP 
				•	Browser: Any browser
				•	Frontend: Framework: NetBeans Java Language
				•	Backend: MYSQL Notifier (1.1.6)
				•	Design Tools: NetBeans 8.0



2. CONSTRAINTS
     

	1. Each user is to be identified by their e-mail id for security concerns.
	2. Only Banasthali students(B.tech,M.tech,BCA,MCA) can register themselves.
	3. The internet connection must be established.	
	


3. FEATURES
				  

	The main objective of this software product is to design software, which facilitates all functionalities for               better management of placement and to guide the students.


4. Installation
   
	SERVER (WAMP)

   		.  Download wamp server.
   		.  Install the software.
   		.  Test the installation process.
  		.  Do the configuration process.
 


			

